<?php

return [
    'production' => true,
];
